
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import authRoutes from './routes/auth';

const app = express();
const PORT = process.env.PORT || 8080;

// Security Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json({ limit: '10mb' })); // Higher limit for images
app.use(cookieParser());

// Rate Limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', apiLimiter);

// Health Check (Cloud Run)
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

// Routes
app.use('/api/auth', authRoutes);

// Protected Route Middleware Example
// In a real file, this would be in middleware/auth.ts
const requireAuth = (req: any, res: any, next: any) => {
    // Logic to verify Bearer token from headers using JWT_SECRET
    next();
};

app.get('/api/user/profile', requireAuth, (req, res) => {
    // Return user profile
    res.json({ message: "Protected profile data" });
});

app.listen(PORT, () => {
  console.log(`Accolade Backend running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV}`);
});
