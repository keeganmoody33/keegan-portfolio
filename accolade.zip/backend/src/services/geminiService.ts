
import { GoogleGenAI } from "@google/genai";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface RedactionResult {
  originalImageUrl: string; // The specific GCS bucket path or signed URL
  summary: string;
  piiDetected: string[];
  confidence: number;
}

/**
 * Uses Gemini 3 Vision to analyze a screenshot, identify PII, 
 * and return a safe, professional summary of the metric.
 */
export const redactScreenshot = async (
  userId: string,
  imageBase64: string,
  mimeType: string = "image/png"
): Promise<RedactionResult> => {
  
  const model = "gemini-3-pro-preview";
  
  const prompt = `
    You are a Data Privacy Officer. Analyze this screenshot of a business dashboard (e.g., Salesforce, Stripe, GitHub).
    
    Tasks:
    1. Identify any Personally Identifiable Information (PII) such as specific client names, email addresses, phone numbers, or exact account IDs.
    2. Identify specific dollar amounts or exact trade secrets.
    3. Generate a "Safe Summary" that describes the achievement without revealing sensitive data. 
       - Bad: "Closed deal with Acme Corp for $500,000"
       - Good: "Closed enterprise deal in the manufacturing sector valued at mid-six figures."
    
    Output JSON format:
    {
      "summary": "string",
      "piiDetected": ["list of categories found, e.g., 'Email', 'Client Name'"],
      "confidence": number (0-1)
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
            { inlineData: { mimeType, data: imageBase64 } },
            { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");

    // Audit Log for Compliance
    await prisma.auditLog.create({
      data: {
        userId,
        action: "GEMINI_REDACTION",
        resourceType: "SCREENSHOT",
        changePayload: { piiDetected: result.piiDetected },
        timestamp: new Date()
      }
    });

    return {
      originalImageUrl: "pending_upload_logic", // Placeholder for GCS logic
      summary: result.summary || "Unable to generate summary",
      piiDetected: result.piiDetected || [],
      confidence: result.confidence || 0
    };

  } catch (error) {
    console.error("Gemini Redaction Error:", error);
    throw new Error("Failed to process redaction request");
  }
};
