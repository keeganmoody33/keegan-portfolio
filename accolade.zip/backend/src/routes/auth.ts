
import express from 'express';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { adminAuth } from '../config/firebase'; // Assumes firebase-admin is setup

const router = express.Router();
const prisma = new PrismaClient();

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const REFRESH_SECRET = process.env.REFRESH_SECRET || 'dev-refresh-secret';

// Schema for login request
const loginSchema = z.object({
  idToken: z.string(), // Firebase ID Token from frontend
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const { idToken } = loginSchema.parse(req.body);

    // 1. Verify Firebase Token
    const decodedToken = await adminAuth.verifyIdToken(idToken);
    const { uid, email, picture } = decodedToken;

    if (!email) throw new Error("Email required");

    // 2. Sync User to Database (Upsert)
    let user = await prisma.user.upsert({
      where: { email },
      update: { googleOauthId: uid },
      create: {
        email,
        googleOauthId: uid,
      }
    });

    // 3. Generate Custom Backend Tokens
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email, role: 'user' },
      JWT_SECRET,
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { userId: user.id },
      REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    // 4. Set HttpOnly Cookies
    res.cookie('accolade_refresh', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });

    // 5. Audit Log
    await prisma.auditLog.create({
      data: {
        userId: user.id,
        action: "LOGIN",
        resourceType: "AUTH_SESSION",
        changePayload: { method: "FIREBASE_OAUTH" }
      }
    });

    res.json({ accessToken, user: { id: user.id, email: user.email } });

  } catch (error) {
    console.error("Login failed:", error);
    res.status(401).json({ error: "Authentication failed" });
  }
});

// POST /auth/refresh
router.post('/refresh', async (req, res) => {
  const refreshToken = req.cookies.accolade_refresh;
  if (!refreshToken) return res.status(401).json({ error: "No refresh token" });

  try {
    const payload = jwt.verify(refreshToken, REFRESH_SECRET) as any;
    
    // Check if user still exists/is active
    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!user) throw new Error("User not found");

    // Issue new Access Token
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email, role: 'user' },
      JWT_SECRET,
      { expiresIn: '15m' }
    );

    res.json({ accessToken });
  } catch (error) {
    res.status(403).json({ error: "Invalid refresh token" });
  }
});

// POST /auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('accolade_refresh');
  res.json({ message: "Logged out" });
});

export default router;
