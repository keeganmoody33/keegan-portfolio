
import React, { useState, useEffect } from 'react';
import { Artifact, ArtifactType } from '../types';
import { generateArtifactSpeech, editArtifactImage } from '../services/geminiService';
import { X, TrendingUp, Image as ImageIcon, Terminal, Github, ExternalLink, Globe, Play, Search, Printer, ShieldCheck, Volume2, Loader2, Sparkles, Edit2, Save, Trash2, AlertOctagon } from 'lucide-react';
import { BarChart, Bar, ResponsiveContainer, XAxis, Tooltip as RechartsTooltip, CartesianGrid, YAxis } from 'recharts';

interface PreviewModalProps {
  artifact: Artifact | null;
  onClose: () => void;
  onDelete: (id: string) => void;
}

const PreviewModal: React.FC<PreviewModalProps> = ({ artifact, onClose, onDelete }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);

  // Image Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const [isProcessingEdit, setIsProcessingEdit] = useState(false);
  const [displayImage, setDisplayImage] = useState<string | undefined>(undefined);

  // Delete State
  const [isDeleteConfirm, setIsDeleteConfirm] = useState(false);

  // Initialize display image when artifact opens
  useEffect(() => {
    if (artifact?.imageUrl) {
        setDisplayImage(artifact.imageUrl);
    }
    // Reset confirmation when artifact changes
    setIsDeleteConfirm(false);
  }, [artifact]);

  if (!artifact) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDelete = () => {
    if (isDeleteConfirm) {
        onDelete(artifact.id);
    } else {
        setIsDeleteConfirm(true);
    }
  };

  const handleNarrate = async () => {
      if (audioUrl) {
          const audio = new Audio(audioUrl);
          audio.play();
          setIsPlaying(true);
          audio.onended = () => setIsPlaying(false);
          return;
      }

      setIsLoadingAudio(true);
      const textToSpeak = `Title: ${artifact.title}. ${artifact.description}. Impact: ${artifact.impact || 'Not specified'}.`;
      
      const base64Audio = await generateArtifactSpeech(textToSpeak);
      if (base64Audio) {
          try {
             // Decode Base64 to ArrayBuffer
             const binaryString = window.atob(base64Audio);
             const len = binaryString.length;
             const bytes = new Uint8Array(len);
             for (let i = 0; i < len; i++) {
                bytes[i] = binaryString.charCodeAt(i);
             }
             
             const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
             // Assuming 24000Hz sample rate from documentation example
             const buffer = await audioContext.decodeAudioData(bytes.buffer.slice(0) as ArrayBuffer).catch(async () => {
                 // Fallback: If decodeAudioData fails (often due to missing headers), we assume raw PCM and decode manually
                 const pcmData = new Int16Array(bytes.buffer);
                 const audioBuffer = audioContext.createBuffer(1, pcmData.length, 24000);
                 const channelData = audioBuffer.getChannelData(0);
                 for (let i = 0; i < pcmData.length; i++) {
                     channelData[i] = pcmData[i] / 32768.0;
                 }
                 return audioBuffer;
             });

             const source = audioContext.createBufferSource();
             source.buffer = buffer;
             source.connect(audioContext.destination);
             source.start(0);
             setIsPlaying(true);
             source.onended = () => setIsPlaying(false);

          } catch (e) {
              console.error("Audio playback error", e);
          }
      }
      setIsLoadingAudio(false);
  };

  const handleEditImage = async () => {
      if (!displayImage || !editPrompt.trim()) return;
      
      setIsProcessingEdit(true);
      const newImageBase64 = await editArtifactImage(displayImage, editPrompt);
      if (newImageBase64) {
          setDisplayImage(`data:image/png;base64,${newImageBase64}`);
          setIsEditing(false);
          setEditPrompt('');
      }
      setIsProcessingEdit(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 no-print">
      <div className="modal-content bg-[#fff9ed] w-full max-w-6xl h-[90vh] rounded-3xl border-4 border-black shadow-[10px_10px_0px_0px_rgba(255,255,255,0.2)] flex flex-col md:flex-row overflow-hidden relative">
        
        {/* Close Button */}
        <button 
            onClick={onClose} 
            className="absolute top-6 right-6 z-50 p-2 bg-white border-2 border-black hover:bg-red-500 hover:text-white rounded-full text-black transition shadow-[2px_2px_0px_0px_black] no-print"
        >
            <X size={20} strokeWidth={3} />
        </button>

        {/* Action Buttons Container */}
        <div className="absolute top-6 right-20 z-50 flex gap-2 no-print">
            {/* Export Button */}
            <button 
                onClick={handlePrint}
                className="px-4 py-2 bg-black text-white border-2 border-white hover:bg-white hover:text-black hover:border-black rounded-full text-xs font-bold transition shadow-[2px_2px_0px_0px_white] flex items-center gap-2"
            >
                <Printer size={16} />
                EXPORT PDF
            </button>

            {/* Delete Button */}
            <button 
                onClick={handleDelete}
                onMouseLeave={() => setIsDeleteConfirm(false)}
                className={`px-4 py-2 border-2 rounded-full text-xs font-bold transition shadow-[2px_2px_0px_0px_white] flex items-center gap-2 ${
                    isDeleteConfirm 
                    ? 'bg-red-600 text-white border-white animate-pulse' 
                    : 'bg-white text-gray-700 border-gray-300 hover:border-red-500 hover:text-red-500'
                }`}
            >
                {isDeleteConfirm ? <AlertOctagon size={16} /> : <Trash2 size={16} />}
                {isDeleteConfirm ? 'PERMANENT DELETE?' : 'DELETE'}
            </button>
        </div>

        {/* ----------------------------------------------------------
            LEFT PANEL: VISUAL PREVIEW
        ---------------------------------------------------------- */}
        <div className="flex-grow relative flex items-center justify-center p-8 overflow-hidden bg-gray-100 border-r-4 border-black">
             {/* Transparency Checkerboard Background */}
             <div 
                className="absolute inset-0 opacity-[0.15]"
                style={{
                    backgroundImage: `
                        linear-gradient(45deg, #000 25%, transparent 25%), 
                        linear-gradient(-45deg, #000 25%, transparent 25%), 
                        linear-gradient(45deg, transparent 75%, #000 75%), 
                        linear-gradient(-45deg, transparent 75%, #000 75%)
                    `,
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                }}
             ></div>

            {/* Artifact Content Container */}
            <div className="relative z-10 w-full max-w-3xl max-h-full flex flex-col transition-transform duration-500">
                
                {artifact.videoUrl ? (
                    // VIDEO PLAYER
                    <div className="w-full h-full min-h-[400px] bg-black rounded-xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center overflow-hidden relative">
                         <video 
                            src={artifact.videoUrl} 
                            controls 
                            className="max-w-full max-h-[80vh]"
                        />
                    </div>
                ) : displayImage ? (
                     <div className="w-full h-full min-h-[400px] bg-white rounded-xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center overflow-hidden relative group">
                        <img src={displayImage} alt={artifact.title} className="max-w-full max-h-[80vh] object-contain" />
                         
                         {/* Edit Overlay */}
                         {isEditing && (
                            <div className="absolute inset-x-0 bottom-0 p-4 bg-black/80 backdrop-blur flex items-center gap-2 animate-in slide-in-from-bottom-5">
                                <Sparkles className="text-yellow-400 shrink-0" />
                                <input 
                                    type="text" 
                                    autoFocus
                                    placeholder="e.g. Add a neon glow, make it retro..."
                                    value={editPrompt}
                                    onChange={(e) => setEditPrompt(e.target.value)}
                                    className="flex-1 bg-transparent text-white border-b-2 border-white/30 focus:border-yellow-400 outline-none px-2 py-1 text-sm font-bold placeholder-white/50"
                                    onKeyDown={(e) => e.key === 'Enter' && handleEditImage()}
                                />
                                <button 
                                    onClick={handleEditImage}
                                    disabled={isProcessingEdit}
                                    className="bg-yellow-400 text-black px-3 py-1 rounded font-bold text-xs hover:bg-yellow-300 disabled:opacity-50"
                                >
                                    {isProcessingEdit ? <Loader2 size={14} className="animate-spin" /> : 'GENERATE'}
                                </button>
                                <button onClick={() => setIsEditing(false)} className="text-white hover:text-red-400"><X size={16} /></button>
                            </div>
                         )}

                         {!isEditing && (
                            <div className="absolute bottom-4 right-4 flex gap-2">
                                <button 
                                    onClick={() => setIsEditing(true)}
                                    className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 border-2 border-black hover:bg-black hover:text-white transition-colors shadow-[2px_2px_0px_0px_black]"
                                >
                                    <Edit2 size={14} />
                                    EDIT IMAGE
                                </button>
                                {artifact.linkUrl && (
                                    <a 
                                        href={artifact.linkUrl} 
                                        target="_blank" 
                                        rel="noreferrer"
                                        className="bg-black text-white px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2 border-2 border-white hover:bg-white hover:text-black hover:border-black transition-colors shadow-[2px_2px_0px_0px_rgba(255,255,255,0.5)]"
                                    >
                                        <ExternalLink size={14} />
                                        SOURCE
                                    </a>
                                )}
                            </div>
                         )}
                     </div>
                ) : (
                    <>
                        {/* 2. Project / Github / Code (Retro Terminal Look) */}
                        {artifact.type === ArtifactType.PROJECT && (
                            <div className="bg-[#1e1e1e] border-4 border-black w-full h-full min-h-[500px] flex flex-col rounded-xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                                {/* Retro Terminal Header */}
                                <div className="bg-[#e5e5e5] px-4 py-3 flex items-center justify-between border-b-4 border-black select-none">
                                    <div className="flex gap-2">
                                        <div className="w-4 h-4 rounded-full bg-white border-2 border-black" />
                                        <div className="w-4 h-4 rounded-full bg-black border-2 border-white" />
                                        <div className="w-4 h-4 rounded-full bg-gray-400 border-2 border-black" />
                                    </div>
                                    <div className="text-xs font-mono font-bold text-black uppercase tracking-widest flex items-center gap-2">
                                        {artifact.githubUrl ? 'GITHUB.EXE' : 'SOURCE_CODE'}
                                    </div>
                                </div>

                                {/* Code Content */}
                                <div className="p-8 overflow-auto custom-scrollbar flex-1 bg-[#1e1e1e]">
                                    <pre className="font-mono text-sm leading-loose text-green-400">
                                        <code>
                                        {artifact.snippet || `// Artifact: ${artifact.title}
// Status: ${artifact.validation?.isVerified ? 'VERIFIED' : 'PENDING'}

function renderArtifact() {
  const impact = "${artifact.impact}";
  return (
    <View>
      <Impact value={impact} />
    </View>
  );
}`}
                                        </code>
                                    </pre>
                                </div>
                                <div className="bg-[#252526] p-4 border-t-2 border-gray-700 flex gap-4">
                                     {artifact.githubUrl && (
                                            <a 
                                                href={artifact.githubUrl} 
                                                target="_blank" 
                                                rel="noreferrer"
                                                className="text-gray-400 hover:text-white font-mono text-xs flex items-center gap-2"
                                            >
                                                <Github size={14} />
                                                REPO
                                            </a>
                                        )}
                                </div>
                            </div>
                        )}

                        {/* 3. Stats Chart (Updated Kool-Aid Vintage Look) */}
                        {artifact.type === ArtifactType.STATS && (
                            <div className="bg-white rounded-xl border-4 border-black w-full h-full min-h-[400px] flex flex-col shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden">
                                {/* Vintage Header - Blue Raspberry Flavor */}
                                <div className="bg-[#2563EB] p-6 border-b-4 border-black flex justify-between items-center relative">
                                    <div>
                                        <h4 className="text-white text-xs font-black uppercase tracking-widest mb-1 opacity-80">Primary Metric</h4>
                                        <div className="text-4xl font-black text-white leading-none tracking-tight">{artifact.revenue || "Growth"}</div>
                                    </div>
                                    <div className="bg-[#fff] text-[#2563EB] border-2 border-black px-4 py-1.5 rounded-full text-xs font-black uppercase shadow-[2px_2px_0px_0px_black] transform rotate-2">
                                        {artifact.validation?.isVerified ? 'Verified' : 'Projected'}
                                    </div>
                                    
                                    {/* Dotted texture overlay for header */}
                                    <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(white 1px, transparent 1px)', backgroundSize: '4px 4px' }}></div>
                                </div>

                                <div className="flex-grow p-8 bg-white relative flex flex-col">
                                    {/* Graph Area Container with Dashed Border */}
                                    <div className="flex-1 border-4 border-dashed border-[#9333EA] rounded-xl p-4 relative">
                                        {artifact.chartData ? (
                                            <ResponsiveContainer width="100%" height="100%">
                                                <BarChart data={artifact.chartData} barGap={0} margin={{ top: 20, right: 0, bottom: 0, left: -20 }}>
                                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#000" strokeOpacity={0.1} strokeWidth={2} />
                                                    <XAxis 
                                                        dataKey="label" 
                                                        axisLine={{ stroke: '#000', strokeWidth: 3 }} 
                                                        tickLine={false} 
                                                        tick={{fill: '#000', fontSize: 14, fontWeight: 800, fontFamily: 'Archivo Black'}} 
                                                        dy={15} 
                                                    />
                                                    <YAxis 
                                                        axisLine={false} 
                                                        tickLine={false} 
                                                        tick={{fill: '#9CA3AF', fontSize: 12, fontWeight: 700}} 
                                                    />
                                                    <Bar 
                                                        dataKey="value" 
                                                        fill="#2563EB" 
                                                        stroke="#000" 
                                                        strokeWidth={3}
                                                        radius={[0, 0, 0, 0]} 
                                                        barSize={60} 
                                                    />
                                                    <RechartsTooltip 
                                                        cursor={{fill: '#EFF6FF', opacity: 0.5}}
                                                        contentStyle={{ 
                                                            borderRadius: '0px', 
                                                            border: '3px solid black', 
                                                            boxShadow: '4px 4px 0px 0px black', 
                                                            backgroundColor: '#fff', 
                                                            color: '#000',
                                                            fontFamily: 'Public Sans',
                                                            fontWeight: 'bold'
                                                        }}
                                                        itemStyle={{ color: '#2563EB' }}
                                                    />
                                                </BarChart>
                                            </ResponsiveContainer>
                                        ) : (
                                            <div className="flex items-center justify-center h-full text-gray-300 font-bold text-lg">No Chart Data</div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* 4. Fallback Design */}
                        {artifact.type === ArtifactType.DESIGN && !displayImage && !artifact.videoUrl && (
                             <div className="w-full h-full min-h-[400px] bg-white rounded-xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center">
                                <div className="text-center p-10">
                                    <div className="w-32 h-32 bg-yellow-300 border-4 border-black rounded-full flex items-center justify-center mx-auto mb-6">
                                        <Globe size={64} className="text-black" />
                                    </div>
                                    <h3 className="text-3xl font-black text-black uppercase">Visual Asset</h3>
                                    {artifact.linkUrl && (
                                        <a href={artifact.linkUrl} target="_blank" rel="noreferrer" className="inline-block mt-4 text-white bg-black px-6 py-2 rounded-full font-bold hover:bg-blue-600 transition-colors">
                                            OPEN EXTERNAL LINK
                                        </a>
                                    )}
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>

        {/* ----------------------------------------------------------
            RIGHT PANEL: DETAILS
        ---------------------------------------------------------- */}
        <div className="w-full md:w-[420px] bg-white flex flex-col h-full overflow-y-auto shrink-0 z-20 print-only">
            <div className="p-10 space-y-10">
                
                {/* Header Info */}
                <div>
                     <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                            <span className={`px-3 py-1 rounded-md text-xs font-black uppercase tracking-widest border-2 border-black ${
                                artifact.type === ArtifactType.STATS ? 'bg-blue-500 text-white' :
                                artifact.type === ArtifactType.DESIGN ? 'bg-yellow-400 text-black' :
                                'bg-red-500 text-white'
                            }`}>
                                {artifact.type}
                            </span>
                            
                            {artifact.redaction?.isRedacted && (
                                <span className="flex items-center gap-1 px-3 py-1 rounded-md text-xs font-black uppercase tracking-widest border border-green-600 text-green-700 bg-green-50">
                                    <ShieldCheck size={12} />
                                    ANONYMIZED
                                </span>
                            )}
                        </div>
                        
                        {/* Narrate Button */}
                        <button 
                            onClick={handleNarrate}
                            disabled={isLoadingAudio}
                            className={`flex items-center gap-2 text-xs font-black uppercase tracking-wider transition-colors ${isPlaying ? 'text-green-600 animate-pulse' : 'text-gray-400 hover:text-black'}`}
                        >
                            {isLoadingAudio ? <Loader2 size={16} className="animate-spin" /> : <Volume2 size={16} />}
                            {isPlaying ? 'Playing...' : 'Narrate'}
                        </button>
                    </div>

                    <h2 className="text-4xl font-black text-black leading-none mb-6">{artifact.title}</h2>
                    <p className="text-gray-800 text-base font-medium leading-relaxed border-l-4 border-black pl-4">{artifact.description}</p>
                </div>

                {/* IMPACT SECTION & SCORE */}
                {(artifact.impact || artifact.revenue || artifact.impactScore) && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 delay-200">
                        <div className="bg-indigo-50 p-6 rounded-xl border-2 border-black shadow-[4px_4px_0px_0px_#4F46E5]">
                             <div className="flex justify-between items-start mb-4">
                                <h3 className="text-xs font-black text-indigo-800 uppercase tracking-widest mb-2">Impact</h3>
                                {artifact.impactScore !== undefined && (
                                    <div className="flex flex-col items-end">
                                        <span className="text-[10px] font-black uppercase text-indigo-400">Score</span>
                                        <div className="text-2xl font-black text-black leading-none">{artifact.impactScore}</div>
                                    </div>
                                )}
                             </div>
                            <p className="text-black font-bold">{artifact.impact}</p>
                            {artifact.revenue && (
                                <div className="mt-4 pt-4 border-t-2 border-indigo-200 flex items-center gap-2 text-indigo-700 font-black text-xl">
                                    <TrendingUp size={24} />
                                    {artifact.revenue}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* GROUNDING SOURCES (SEARCH DATA) */}
                {artifact.groundingSources && artifact.groundingSources.length > 0 && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 delay-300">
                        <div className="bg-white p-4 rounded-xl border-2 border-black border-dashed">
                             <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                <Search size={12} />
                                Verified Sources
                             </h3>
                             <ul className="space-y-2">
                                {artifact.groundingSources.slice(0, 3).map((source, i) => (
                                    <li key={i}>
                                        <a href={source.uri} target="_blank" rel="noreferrer" className="text-xs font-bold text-blue-600 hover:underline block truncate">
                                            {source.title || source.uri}
                                        </a>
                                    </li>
                                ))}
                             </ul>
                        </div>
                    </div>
                )}

                {/* TECH STACK */}
                {artifact.techStack && artifact.techStack.length > 0 && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 delay-300">
                         <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Tools Used</h3>
                        <div className="flex flex-wrap gap-2">
                            {artifact.techStack.map(t => (
                                <span key={t} className="px-3 py-1 bg-black text-white rounded-md text-xs font-bold border-2 border-transparent hover:bg-white hover:text-black hover:border-black transition-colors cursor-default">
                                    {t}
                                </span>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewModal;
