import React, { useEffect, useState } from 'react';
import { Artifact } from '../types';
import { generateVaultSummary } from '../services/geminiService';
import { X, Sparkles, Loader2, Award, Briefcase } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface SummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  artifacts: Artifact[];
}

const SummaryModal: React.FC<SummaryModalProps> = ({ isOpen, onClose, artifacts }) => {
  const [summary, setSummary] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen && artifacts.length > 0) {
        setIsLoading(true);
        generateVaultSummary(artifacts)
            .then(setSummary)
            .catch(err => setSummary("Failed to compile summary."))
            .finally(() => setIsLoading(false));
    }
  }, [isOpen, artifacts]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#fff9ed] w-full max-w-3xl rounded-3xl shadow-[12px_12px_0px_0px_rgba(255,255,255,0.2)] flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in duration-300 border-4 border-black">
        
        {/* Header */}
        <div className="relative bg-[#9333EA] text-white p-8 overflow-hidden shrink-0 border-b-4 border-black">
             <div className="absolute top-0 right-0 p-12 opacity-20 transform rotate-12">
                <Award size={140} className="text-black" />
             </div>
             
             <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white text-black border-2 border-black rounded-full hover:bg-black hover:text-white transition shadow-[2px_2px_0px_0px_black]">
                <X size={20} strokeWidth={3} />
            </button>

            <div className="relative z-10 flex items-center gap-3 mb-2">
                <div className="bg-yellow-400 p-1 border-2 border-black rounded shadow-[2px_2px_0px_0px_black]">
                    <Briefcase className="text-black" size={20} />
                </div>
                <span className="text-yellow-300 text-xs font-black uppercase tracking-widest">Executive Brief</span>
            </div>
            <h2 className="relative z-10 text-4xl font-black tracking-tighter mb-2 italic">Career Compilation</h2>
            <p className="relative z-10 text-purple-200 font-bold max-w-lg">Your entire vault, mashed into a single cohesive narrative.</p>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-10 bg-white">
            {isLoading ? (
                <div className="flex flex-col items-center justify-center h-64 space-y-6">
                    <Loader2 className="w-16 h-16 text-black animate-spin" />
                    <p className="text-black text-lg font-black animate-pulse uppercase">Blending Artifacts...</p>
                </div>
            ) : (
                <div className="prose prose-lg max-w-none text-black font-medium leading-relaxed">
                     <ReactMarkdown
                        components={{
                            h2: ({node, ...props}) => <h2 className="text-2xl font-black text-black mt-8 mb-4 flex items-center gap-2 border-b-4 border-yellow-300 inline-block pr-4" {...props} />,
                            h3: ({node, ...props}) => <h3 className="text-xl font-black text-gray-800 mt-6 mb-2 uppercase" {...props} />,
                            strong: ({node, ...props}) => <span className="font-black text-black bg-yellow-200 px-1 border border-black rounded-sm shadow-[2px_2px_0px_0px_black]" {...props} />,
                            p: ({node, ...props}) => <p className="mb-4 text-gray-800" {...props} />,
                            li: ({node, ...props}) => <li className="marker:text-black marker:font-black mb-2" {...props} />
                        }}
                     >
                        {summary}
                     </ReactMarkdown>
                </div>
            )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t-4 border-black bg-gray-50 flex justify-between items-center">
            <div className="flex items-center gap-2 text-xs text-gray-500 font-black uppercase tracking-wider">
                <Sparkles size={14} className="text-yellow-500" />
                Generated from {artifacts.length} Artifacts
            </div>
            <button onClick={onClose} className="px-6 py-3 bg-white border-2 border-black hover:bg-black hover:text-white text-black rounded-xl text-sm font-black transition shadow-[2px_2px_0px_0px_black]">
                CLOSE BRIEF
            </button>
        </div>
      </div>
    </div>
  );
};

export default SummaryModal;