
import React from 'react';
import { Artifact, ArtifactType } from '../types';
import { BarChart, Bar, ResponsiveContainer, XAxis, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { FileCode, Image as ImageIcon, TrendingUp, Zap, Calendar, DollarSign, Lightbulb, Code2, Maximize2, Link as LinkIcon, Github, ShieldCheck, Target, PieChart as PieIcon, Activity, Play } from 'lucide-react';
import { isFeatureEnabled, FEATURES } from '../services/featureFlags';

interface ArtifactCardProps {
  artifact: Artifact;
  onPreview?: (artifact: Artifact) => void;
}

const ArtifactCard: React.FC<ArtifactCardProps> = ({ artifact, onPreview }) => {
  const isAdvancedVizEnabled = isFeatureEnabled(FEATURES.ADVANCED_VISUALIZATIONS);
  
  // "Flavor" Colors based on type
  const getHeaderStyle = () => {
    switch (artifact.type) {
        case ArtifactType.STATS:
            return 'bg-[#2563EB] text-white border-b-2 border-black'; // Blue Raspberry
        case ArtifactType.PROJECT:
            return 'bg-[#DC2626] text-white border-b-2 border-black'; // Tropical Punch
        case ArtifactType.DESIGN:
            return 'bg-[#FACC15] text-black border-b-2 border-black'; // Lemonade
        default:
            return 'bg-gray-800 text-white border-b-2 border-black';
    }
  };

  const renderChart = () => {
      if (!artifact.chartData) return null;
      
      const chartType = isAdvancedVizEnabled && artifact.chartConfig ? artifact.chartConfig.type : 'bar';
      
      // Default Tooltip Style
      const tooltipStyle = {
          contentStyle: { 
             borderRadius: '8px', 
             border: '2px solid black', 
             boxShadow: '4px 4px 0px 0px black', 
             backgroundColor: '#fff', 
             color: '#000',
             fontWeight: 'bold',
             fontSize: '10px',
             padding: '4px 8px'
         }
      };

      if (chartType === 'line') {
          return (
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={artifact.chartData}>
                    <Line type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={3} dot={{r: 3, fill: '#000'}} />
                    <Tooltip {...tooltipStyle} />
                </LineChart>
            </ResponsiveContainer>
          );
      } else if (chartType === 'area') {
           return (
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={artifact.chartData}>
                    <Area type="monotone" dataKey="value" stroke="#2563EB" fill="#93C5FD" strokeWidth={2} />
                    <Tooltip {...tooltipStyle} />
                </AreaChart>
            </ResponsiveContainer>
          );
      } else if (chartType === 'pie') {
          const COLORS = ['#2563EB', '#FACC15', '#DC2626', '#10B981'];
          return (
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie data={artifact.chartData} dataKey="value" nameKey="label" cx="50%" cy="50%" outerRadius={40} stroke="#000" strokeWidth={2}>
                        {artifact.chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip {...tooltipStyle} />
                </PieChart>
            </ResponsiveContainer>
          );
      }

      // Default Bar
      return (
        <ResponsiveContainer width="100%" height="100%">
            <BarChart data={artifact.chartData}>
                <Bar dataKey="value" fill="#1a1a1a" radius={[4, 4, 0, 0]} />
                <XAxis dataKey="label" hide />
                <Tooltip {...tooltipStyle} cursor={{fill: 'transparent'}} />
            </BarChart>
        </ResponsiveContainer>
      );
  };

  return (
    <div 
        className="bg-white border-2 border-black rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 flex flex-col h-full group relative cursor-default"
    >
      
      {/* Revenue Badge (Sticker Style) */}
      {artifact.revenue && (
          <div className="absolute top-3 right-3 z-10 bg-[#22c55e] text-white border-2 border-black px-2 py-1 rounded-md shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1 transform rotate-2 group-hover:rotate-0 transition-transform">
              <DollarSign size={14} className="stroke-[4px]" />
              <span className="text-xs font-black tracking-tighter">{artifact.revenue}</span>
          </div>
      )}

      {/* Retro Header */}
      <div className={`px-4 py-3 flex justify-between items-center ${getHeaderStyle()}`}>
        <div className="flex items-center gap-2">
            {artifact.type === ArtifactType.STATS && <TrendingUp size={18} strokeWidth={3} />}
            {artifact.type === ArtifactType.DESIGN && <ImageIcon size={18} strokeWidth={3} />}
            {artifact.type === ArtifactType.PROJECT && <FileCode size={18} strokeWidth={3} />}
            <span className="text-xs font-black tracking-widest uppercase">{artifact.type}</span>
        </div>
        
        {/* Link Icons */}
        <div className="flex gap-2 mr-8">
            {artifact.githubUrl && <Github size={16} strokeWidth={2.5} />}
            {artifact.linkUrl && <LinkIcon size={16} strokeWidth={2.5} />}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-5 flex-grow flex flex-col">
        <h3 
            className="text-xl font-black text-black mb-2 leading-tight group-hover:text-blue-600 transition-colors cursor-pointer" 
            onClick={() => onPreview?.(artifact)}
        >
            {artifact.title}
        </h3>
        
        {/* Description & Impact Bubbles */}
        <div className="space-y-3 mb-4">
            <p className="text-sm font-medium text-gray-600 line-clamp-3 leading-relaxed">
                {artifact.description}
            </p>
            
            {(artifact.impact || artifact.inspiration) && (
                <div className="bg-gray-100 p-3 rounded-lg border-2 border-black space-y-2">
                    {/* Impact Score Display */}
                    {artifact.impactScore !== undefined && (
                        <div className="flex items-center justify-between mb-2 pb-2 border-b-2 border-gray-200">
                             <div className="flex items-center gap-1 text-[10px] font-black uppercase text-gray-500 tracking-widest">
                                <Target size={12} />
                                Impact Score
                             </div>
                             <div className="text-sm font-black text-black bg-yellow-300 px-2 rounded border border-black shadow-[1px_1px_0px_0px_black]">
                                {artifact.impactScore}/100
                             </div>
                        </div>
                    )}

                    {artifact.inspiration && (
                        <div className="flex gap-2 items-start">
                            <Lightbulb size={16} className="text-amber-500 shrink-0 mt-0.5 fill-amber-500 stroke-black stroke-[1.5px]" />
                            <p className="text-xs font-bold text-gray-800 italic">"{artifact.inspiration}"</p>
                        </div>
                    )}
                    {artifact.impact && (
                        <div className="flex gap-2 items-start">
                            <Zap size={16} className="text-indigo-500 shrink-0 mt-0.5 fill-indigo-500 stroke-black stroke-[1.5px]" />
                            <p className="text-xs font-black text-black uppercase">{artifact.impact}</p>
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Dynamic Content Visualization */}
        <div 
            className="mt-auto mb-4 bg-white rounded-lg p-2 border-2 border-dashed border-gray-300 h-32 flex items-center justify-center overflow-hidden relative cursor-pointer group/preview hover:border-black hover:border-solid transition-all"
            onClick={() => onPreview?.(artifact)}
        >
            {artifact.imageUrl ? (
                <div className="w-full h-full relative">
                    <img src={artifact.imageUrl} alt="Preview" className="w-full h-full object-cover rounded-md grayscale group-hover/preview:grayscale-0 transition-all" />
                    {artifact.type === ArtifactType.DESIGN && (
                        <div className="absolute bottom-1 right-1 bg-yellow-400 text-black p-1 rounded-full opacity-0 group-hover/preview:opacity-100 transition-opacity">
                            <ImageIcon size={12} />
                        </div>
                    )}
                </div>
            ) : artifact.videoUrl ? (
                <div className="w-full h-full relative">
                    <video 
                        src={artifact.videoUrl} 
                        className="w-full h-full object-cover rounded-md grayscale group-hover/preview:grayscale-0 transition-all"
                        muted 
                        loop 
                        playsInline
                        onMouseOver={e => e.currentTarget.play()}
                        onMouseOut={e => {
                            e.currentTarget.pause();
                            e.currentTarget.currentTime = 0;
                        }}
                    />
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/50 text-white rounded-full p-2 group-hover/preview:opacity-0 transition-opacity">
                        <Play size={16} fill="currentColor" />
                    </div>
                </div>
            ) : artifact.type === ArtifactType.STATS && artifact.chartData ? (
               <>
                 {renderChart()}
                 {/* Viz Badge */}
                 {isAdvancedVizEnabled && artifact.chartConfig && artifact.chartConfig.type !== 'bar' && (
                     <div className="absolute bottom-1 right-1 bg-black text-white text-[8px] font-black uppercase px-1 rounded opacity-50">
                        {artifact.chartConfig.type}
                     </div>
                 )}
               </>
            ) : artifact.type === ArtifactType.PROJECT ? (
                 <div className="w-full h-full bg-slate-900 rounded-md p-3 flex flex-col relative overflow-hidden border border-gray-800">
                    {artifact.snippet ? (
                        <pre className="mt-1 font-mono text-[9px] text-green-400 leading-relaxed opacity-90 overflow-hidden whitespace-pre-wrap">
                            {artifact.snippet}
                        </pre>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <Code2 size={32} className="text-slate-700" />
                        </div>
                    )}
                 </div>
            ) : artifact.type === ArtifactType.DESIGN ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-[#fff9ed] rounded-md relative overflow-hidden group-hover/preview:bg-yellow-50 transition-colors">
                     {/* Checkerboard background for 'transparent' design feel */}
                     <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(45deg, #000 25%, transparent 25%), linear-gradient(-45deg, #000 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #000 75%), linear-gradient(-45deg, transparent 75%, #000 75%)', backgroundSize: '10px 10px', backgroundPosition: '0 0, 0 5px, 5px -5px, -5px 0px' }}></div>
                     
                     <div className="relative z-10 flex flex-col items-center">
                        <ImageIcon size={24} className="text-gray-400 mb-1 group-hover/preview:text-yellow-600 transition-colors" />
                        <span className="text-[9px] font-black uppercase text-gray-400 group-hover/preview:text-yellow-700 transition-colors">Visual Asset</span>
                     </div>
                </div>
            ) : (
                <div className="w-full h-full flex items-center justify-center bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
                     <div className="bg-white border-2 border-black p-2 rounded shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        <ImageIcon size={24} className="text-black" />
                     </div>
                </div>
            )}
        </div>

        {/* Tags & Timeframe Footer */}
        <div className="flex flex-wrap gap-2 items-center justify-between mt-auto pt-4 border-t-2 border-gray-100">
            <div className="flex flex-wrap gap-1">
                {artifact.tags.slice(0, 3).map((tag, i) => (
                    <span key={i} className="px-2 py-0.5 bg-white border border-black rounded-md text-[10px] font-bold text-black uppercase shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]">
                        {tag}
                    </span>
                ))}
            </div>
            {artifact.redaction?.isRedacted && (
                <div className="flex items-center gap-1 text-[10px] font-bold text-green-600 border border-green-600 px-2 py-0.5 rounded-full bg-green-50">
                    <ShieldCheck size={10} />
                    ANONYMIZED
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ArtifactCard;
