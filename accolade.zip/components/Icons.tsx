import React, { useId } from 'react';

export const JugIcon: React.FC<{ className?: string; fillLevel?: number }> = ({ className = "w-6 h-6", fillLevel = 0 }) => {
  const id = useId();
  // Ensure fillLevel is between 0 and 1. Cap at 1 (100%).
  const clampedLevel = Math.max(0, Math.min(1, fillLevel));
  const percent = Math.round(clampedLevel * 100);

  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id={`liquid-${id}`} x1="0" x2="0" y1="1" y2="0">
                <stop offset={`${percent}%`} stopColor="#dc2626" />
                <stop offset={`${percent}%`} stopColor="white" />
            </linearGradient>
        </defs>
        
        {/* Main Body with Liquid Fill */}
        <path d="M25 20 H75 L70 80 C70 85 65 90 60 90 H40 C35 90 30 85 30 80 L25 20 Z" 
            stroke="currentColor" 
            strokeWidth="6" 
            fill={`url(#liquid-${id})`}
        />
        {/* Top Rim */}
        <path d="M25 20 H75" stroke="currentColor" strokeWidth="6"/>
        {/* Handle */}
        <path d="M25 30 H15 V60 H28" stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
        {/* Measurement Lines */}
        <line x1="30" y1="35" x2="45" y2="35" stroke="currentColor" strokeWidth="4"/>
        <line x1="30" y1="50" x2="50" y2="50" stroke="currentColor" strokeWidth="4"/>
        <line x1="30" y1="65" x2="45" y2="65" stroke="currentColor" strokeWidth="4"/>
        {/* Face */}
        <circle cx="45" cy="50" r="3" fill="currentColor"/>
        <circle cx="60" cy="50" r="3" fill="currentColor"/>
        <path d="M48 60 Q52.5 65 57 60" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
    </svg>
  );
};

export const CheckBadge: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
   <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/>
      <path d="m9 12 2 2 4-4"/>
    </svg>
);
