
import React, { useState, useRef, useEffect } from 'react';
import { Artifact, ArtifactType } from '../types';
import { generateArtifactNarrative, parseStatsData, transcribeAudio } from '../services/geminiService';
import { X, Sparkles, Loader2, BarChart2, FileText, Image as ImageIcon, Mic, Square, Link as LinkIcon, Upload, Github, Shield, ShieldCheck, Video, Tag as TagIcon, Plus, Calendar, Command } from 'lucide-react';

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (artifact: Artifact) => void;
  existingTags?: string[];
}

const CreateModal: React.FC<CreateModalProps> = ({ isOpen, onClose, onSave, existingTags = [] }) => {
  const [activeType, setActiveType] = useState<ArtifactType>(ArtifactType.STATS);
  const [rawInput, setRawInput] = useState('');
  
  // Tag Management
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [filteredTags, setFilteredTags] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  // New Inputs
  const [linkUrl, setLinkUrl] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  const [timeframe, setTimeframe] = useState('');
  
  // Media State
  const [uploadedMedia, setUploadedMedia] = useState<{data: string, mimeType: string} | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);

  const [isAnonymized, setIsAnonymized] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filter suggestions for tags
  useEffect(() => {
    if (tagInput.trim()) {
        const lowerInput = tagInput.toLowerCase();
        const filtered = existingTags.filter(t => 
            t && t.toLowerCase().includes(lowerInput) && !tags.includes(t)
        );
        setFilteredTags(filtered);
        setShowSuggestions(filtered.length > 0);
    } else {
        setFilteredTags([]);
        setShowSuggestions(false);
    }
  }, [tagInput, existingTags, tags]);

  if (!isOpen) return null;

  const handleAddTag = (tagToAdd: string) => {
    const cleanTag = tagToAdd.trim();
    if (cleanTag && !tags.includes(cleanTag)) {
        setTags([...tags, cleanTag]);
        setTagInput('');
        setFilteredTags([]);
        setShowSuggestions(false);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };

  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        // If there's a suggestion and we just hit enter, take the first one? 
        // Or just take the input value. Let's prioritize input value unless empty, then suggestion.
        if (tagInput.trim()) {
            handleAddTag(tagInput);
        } else if (filteredTags.length > 0) {
            handleAddTag(filteredTags[0]);
        }
    } else if (e.key === 'Tab') {
        // Autocomplete with the first suggestion
        if (filteredTags.length > 0) {
            e.preventDefault();
            handleAddTag(filteredTags[0]);
        }
    }
  };

  // SPEC 3.1: SHA-256 Hash for deduplication
  const computeFileHash = async (base64String: string): Promise<string> => {
    const binaryString = atob(base64String);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    const hashBuffer = await crypto.subtle.digest('SHA-256', bytes);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const result = reader.result as string;
              const base64Data = result.split(',')[1];
              
              setUploadedMedia({
                  data: base64Data,
                  mimeType: file.type
              });
              setMediaPreview(result);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleProcess = async () => {
    if (!rawInput.trim() && !uploadedMedia && !linkUrl && !githubUrl) return;
    
    setIsProcessing(true);
    
    try {
        const textToProcess = rawInput || (uploadedMedia ? "Analyze this uploaded media artifact." : "A linked project.");
        
        // Pass media and linkUrl to service
        const result = await generateArtifactNarrative(
            textToProcess, 
            activeType, 
            uploadedMedia, 
            isAnonymized,
            linkUrl || undefined
        );
        
        const { narrative, sources } = result;
        
        // Combine AI tags with User tags, ensuring uniqueness. Safely handle if narrative.tags is missing.
        const combinedTags = Array.from(new Set([...tags, ...(narrative.tags || [])]));
        
        let chartData = undefined;
        let metricUnit = undefined;

        if (activeType === ArtifactType.STATS) {
            const stats = await parseStatsData(rawInput);
            chartData = stats.data;
            metricUnit = stats.unit;
        }

        let linkType: 'GITHUB' | 'FIGMA' | 'LIVE' | 'OTHER' = 'OTHER';
        if (linkUrl.includes('figma.com')) linkType = 'FIGMA';
        else if (linkUrl) linkType = 'LIVE';

        const isVideo = uploadedMedia?.mimeType.startsWith('video/');

        // Generate Hash if media exists
        const fileHash = uploadedMedia ? await computeFileHash(uploadedMedia.data) : undefined;

        const newArtifact: Artifact = {
            id: crypto.randomUUID(),
            title: narrative.title || "Untitled Artifact",
            description: narrative.description || "No description provided.",
            type: activeType,
            dateCreated: new Date().toISOString(),
            tags: combinedTags,
            inspiration: narrative.inspiration,
            impact: narrative.impact,
            impactScore: narrative.impactScore || 50,
            fileHash: fileHash,
            revenue: narrative.revenue || undefined,
            timeframe: timeframe || narrative.timeframe || undefined,
            techStack: narrative.techStack,
            snippet: narrative.snippet || undefined,
            
            // Validation (Default to verified false for MVP)
            validation: {
                isVerified: false,
                badges: []
            },

            chartData,
            metricUnit,
            imageUrl: !isVideo ? mediaPreview || undefined : undefined,
            videoUrl: isVideo ? mediaPreview || undefined : undefined,
            githubUrl: githubUrl || undefined,
            linkUrl: linkUrl || undefined,
            linkType: linkUrl ? linkType : undefined,
            groundingSources: sources,
            
            // Redaction Metadata
            redaction: {
                isRedacted: isAnonymized,
                zones: narrative.redactionSuggestions || []
            },
            
            source: 'Manual Entry'
        };

        onSave(newArtifact);
        onClose();
        
        // Reset State
        setRawInput('');
        setTags([]);
        setTagInput('');
        setTimeframe('');
        setLinkUrl('');
        setGithubUrl('');
        setUploadedMedia(null);
        setMediaPreview(null);
        setIsAnonymized(false);
    } catch (error) {
        console.error("Creation failed", error);
    } finally {
        setIsProcessing(false);
    }
  };

  const startRecording = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : ''; 
        const mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
        
        mediaRecorderRef.current = mediaRecorder;
        chunksRef.current = [];

        mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) chunksRef.current.push(e.data);
        };

        mediaRecorder.onstop = async () => {
            const blob = new Blob(chunksRef.current, { type: mediaRecorder.mimeType || 'audio/webm' });
            stream.getTracks().forEach(track => track.stop());

            setIsProcessing(true);
            try {
                const base64 = await new Promise<string>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                        const base64String = reader.result as string;
                        resolve(base64String.split(',')[1]);
                    };
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                });
                const text = await transcribeAudio(base64, blob.type);
                setRawInput(prev => (prev.trim() ? prev + '\n\n' + text : text));
            } catch (err) {
                console.error("Transcription error", err);
            } finally {
                setIsProcessing(false);
                setIsRecording(false);
            }
        };

        mediaRecorder.start();
        setIsRecording(true);
    } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Could not access microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
    }
  };

  const toggleRecording = () => {
      if (isRecording) stopRecording();
      else startRecording();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl rounded-3xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b-4 border-black bg-yellow-300">
            <div>
                <h2 className="text-3xl font-black text-black uppercase italic tracking-wider">New Artifact</h2>
                <p className="text-sm font-bold text-black/70">Fill the jug. Feed the vault.</p>
            </div>
            <button onClick={onClose} className="p-2 bg-white border-2 border-black rounded-full hover:bg-red-500 hover:text-white transition-colors shadow-[2px_2px_0px_0px_black]">
                <X size={24} strokeWidth={3} />
            </button>
        </div>

        {/* Type Selector */}
        <div className="flex p-4 bg-white gap-4">
            {[
                { type: ArtifactType.STATS, label: 'Stats', icon: BarChart2, color: 'bg-blue-100 border-blue-500' },
                { type: ArtifactType.PROJECT, label: 'Project', icon: FileText, color: 'bg-red-100 border-red-500' },
                { type: ArtifactType.DESIGN, label: 'Design', icon: ImageIcon, color: 'bg-yellow-100 border-yellow-500' }
            ].map((t) => (
                <button
                    key={t.type}
                    onClick={() => setActiveType(t.type)}
                    className={`flex-1 flex flex-col items-center justify-center gap-2 py-4 rounded-xl text-sm font-black border-4 transition-all uppercase ${
                        activeType === t.type 
                        ? `${t.color} text-black shadow-[4px_4px_0px_0px_black] -translate-y-1` 
                        : 'bg-gray-50 border-gray-200 text-gray-400 hover:border-black hover:text-black'
                    }`}
                >
                    <t.icon size={24} strokeWidth={3} />
                    {t.label}
                </button>
            ))}
        </div>

        {/* Input Area */}
        <div className="px-6 py-4 flex-grow overflow-y-auto relative flex flex-col gap-6">
            
            {/* Text Input */}
            <div className="relative">
                 <div className="flex justify-between items-end mb-2">
                    <label className="block text-xs font-black uppercase tracking-widest text-black">
                        Story / Context
                    </label>
                    
                    <div className="flex gap-4 items-center">
                         {/* Privacy Shield Toggle Switch */}
                         <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setIsAnonymized(!isAnonymized)}>
                            <div className={`text-[10px] font-black uppercase tracking-widest transition-colors ${isAnonymized ? 'text-black' : 'text-gray-400 group-hover:text-black'}`}>
                                Anonymize Data
                            </div>
                            <div className={`relative w-10 h-5 rounded-full border-2 border-black transition-colors ${isAnonymized ? 'bg-green-400' : 'bg-gray-200'}`}>
                                <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-black rounded-full transition-transform ${isAnonymized ? 'translate-x-5' : 'translate-x-0'}`} />
                            </div>
                         </div>

                        <button 
                            onClick={toggleRecording}
                            className={`text-[10px] font-black px-3 py-1.5 rounded-lg border-2 border-black flex items-center gap-1.5 transition-all shadow-[2px_2px_0px_0px_black] hover:translate-y-px hover:shadow-[1px_1px_0px_0px_black] ${
                                isRecording 
                                ? 'bg-red-500 text-white animate-pulse' 
                                : 'bg-white text-black'
                            }`}
                        >
                            {isRecording ? <Square size={12} fill="currentColor" /> : <Mic size={12} />}
                            {isRecording ? 'STOP' : 'NARRATE'}
                        </button>
                    </div>
                </div>
                <textarea
                    value={rawInput}
                    onChange={(e) => setRawInput(e.target.value)}
                    placeholder={activeType === ArtifactType.STATS 
                        ? "e.g., Q1 Sales: 50k, Q2 Sales: 75k..." 
                        : "e.g., Built a Next.js app... (Add a link to use Google Search)"}
                    className="w-full h-32 p-4 bg-gray-50 border-4 border-black rounded-xl focus:bg-white focus:outline-none focus:shadow-[4px_4px_0px_0px_#9333EA] resize-none text-sm font-bold text-black placeholder-gray-400 transition-shadow"
                />
            </div>

            {/* Tags Input (Enhanced) */}
            <div>
                 <label className="block text-xs font-black uppercase tracking-widest text-black mb-2">
                        Tags
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                    {tags.map(tag => (
                        <span key={tag} className="px-3 py-1 bg-black text-white rounded-md text-xs font-bold flex items-center gap-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)]">
                            {tag}
                            <button onClick={() => handleRemoveTag(tag)} className="hover:text-red-400 bg-white/20 rounded-full p-0.5"><X size={10} /></button>
                        </span>
                    ))}
                </div>
                <div className="relative">
                    <div className="flex items-center gap-2 px-3 py-2 bg-white border-2 border-black rounded-xl focus-within:shadow-[4px_4px_0px_0px_black] transition-all">
                        <TagIcon size={16} className="text-black shrink-0" />
                        <input 
                            type="text" 
                            placeholder="Add tags (Tab to autocomplete)..."
                            value={tagInput}
                            onChange={(e) => setTagInput(e.target.value)}
                            onKeyDown={handleTagKeyDown}
                            onFocus={() => { if(tagInput) setShowSuggestions(true); }}
                            className="bg-transparent w-full text-sm font-medium outline-none placeholder-gray-400 text-black"
                        />
                         <button 
                            onClick={() => handleAddTag(tagInput)}
                            disabled={!tagInput.trim()}
                            className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                        >
                            <Plus size={16} />
                        </button>
                    </div>
                    {/* Suggestions Dropdown */}
                    {showSuggestions && (
                        <div className="absolute top-full left-0 right-0 bg-white border-2 border-black rounded-xl mt-1 max-h-40 overflow-y-auto z-50 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-1">
                            <div className="px-3 py-1 text-[10px] font-black uppercase text-gray-400">Suggestions</div>
                            {filteredTags.map((tag, idx) => (
                                <button
                                    key={tag}
                                    onClick={() => handleAddTag(tag)}
                                    className={`w-full text-left px-3 py-2 text-sm font-bold hover:bg-yellow-100 hover:text-black rounded-lg transition-colors flex justify-between group ${idx === 0 ? 'bg-gray-50' : ''}`}
                                >
                                    <span>{tag}</span>
                                    {idx === 0 && <span className="text-[10px] text-gray-400 uppercase font-black group-hover:text-black">Tab</span>}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Timeframe Input */}
            <div>
                 <label className="block text-xs font-black uppercase tracking-widest text-black mb-2">
                        Timeframe
                </label>
                <div className="flex items-center gap-2 px-3 py-2 bg-white border-2 border-black rounded-xl focus-within:shadow-[4px_4px_0px_0px_black] transition-all">
                    <Calendar size={16} className="text-black shrink-0" />
                    <input 
                        type="text" 
                        placeholder="e.g. Q1 2024, Sprint 42, 2023-2024"
                        value={timeframe}
                        onChange={(e) => setTimeframe(e.target.value)}
                        className="bg-transparent w-full text-sm font-medium outline-none placeholder-gray-400 text-black"
                    />
                </div>
            </div>

            {/* Evidence Bar */}
            <div className="space-y-3">
                 <label className="block text-xs font-black uppercase tracking-widest text-black">
                        Proof & Visuals
                </label>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2 px-3 py-3 bg-white border-2 border-black rounded-xl focus-within:shadow-[4px_4px_0px_0px_black] transition-all">
                        <Github size={20} className="text-black shrink-0" />
                        <input 
                            type="text" 
                            placeholder="github.com/..."
                            value={githubUrl}
                            onChange={(e) => setGithubUrl(e.target.value)}
                            className="bg-transparent w-full text-sm font-medium outline-none placeholder-gray-400 text-black"
                        />
                    </div>

                    <div className="flex items-center gap-2 px-3 py-3 bg-white border-2 border-black rounded-xl focus-within:shadow-[4px_4px_0px_0px_black] transition-all">
                        <LinkIcon size={20} className="text-black shrink-0" />
                        <input 
                            type="text" 
                            placeholder="External Link..."
                            value={linkUrl}
                            onChange={(e) => setLinkUrl(e.target.value)}
                            className="bg-transparent w-full text-sm font-medium outline-none placeholder-gray-400 text-black"
                        />
                    </div>
                </div>

                <input 
                    type="file" 
                    ref={fileInputRef}
                    accept="image/*,video/*"
                    className="hidden"
                    onChange={handleMediaUpload}
                />
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-full px-4 py-3 rounded-xl border-2 border-black border-dashed text-sm font-bold flex items-center justify-center gap-2 transition-all hover:bg-gray-50 ${
                        uploadedMedia 
                        ? 'bg-green-100 text-green-800 border-solid' 
                        : 'text-gray-500'
                    }`}
                >
                    {uploadedMedia?.mimeType.startsWith('video/') ? (
                        <Video size={18} />
                    ) : uploadedMedia ? (
                        <ImageIcon size={18} />
                    ) : (
                        <Upload size={18} />
                    )}
                    {uploadedMedia ? 'MEDIA ATTACHED' : 'UPLOAD IMAGE OR VIDEO'}
                </button>
            </div>

            <div className={`p-4 rounded-xl border-2 flex gap-3 items-start transition-colors ${isAnonymized ? 'bg-black border-black text-white' : 'bg-indigo-50 border-indigo-200 text-indigo-900'}`}>
                {isAnonymized ? (
                    <ShieldCheck className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                ) : (
                    <Sparkles className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                )}
                <div className="text-xs font-bold leading-relaxed">
                    {isAnonymized ? (
                        <span><span className="text-green-400 font-black">PRIVACY SHIELD ACTIVE.</span> All employer names, client data, and PII will be redacted.</span>
                    ) : (
                        <span>
                            Accolade AI is active. <br/>
                            • <strong>Pro Vision:</strong> Upload images or video for analysis.<br/>
                            • <strong>Search Grounding:</strong> Add a link to verify details.<br/>
                        </span>
                    )}
                </div>
            </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t-4 border-black flex justify-end gap-3 bg-white">
            <button onClick={onClose} className="px-6 py-3 rounded-xl text-sm font-bold text-black hover:bg-gray-100 transition">
                CANCEL
            </button>
            <button 
                onClick={handleProcess}
                disabled={(!rawInput.trim() && !uploadedMedia && !linkUrl && !githubUrl) || isProcessing || isRecording}
                className="px-8 py-3 bg-black text-white rounded-xl text-sm font-black shadow-[4px_4px_0px_0px_#FF4D4D] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_#FF4D4D] transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none"
            >
                {isProcessing ? (
                    <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        {isRecording ? 'LISTENING...' : 'PROCESSING...'}
                    </>
                ) : (
                    <>
                        GENERATE
                    </>
                )}
            </button>
        </div>
      </div>
    </div>
  );
};

export default CreateModal;