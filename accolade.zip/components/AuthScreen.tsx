
import React, { useState } from 'react';
import { JugIcon } from './Icons';
import { ArrowRight, Lock, User, Mail, ShieldCheck, Loader2, Ghost, AlertTriangle } from 'lucide-react';
import { authService } from '../services/authService';
import { User as UserType } from '../types';

interface AuthScreenProps {
  onAuthSuccess: (user: UserType) => void;
  onGuestAccess: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess, onGuestAccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate network delay for "Juice" effect
    await new Promise(resolve => setTimeout(resolve, 800));

    try {
      let user;
      if (isLogin) {
        user = authService.login(formData.email, formData.password);
      } else {
        if (!formData.name) throw new Error("Name is required");
        user = authService.signup(formData.name, formData.email, formData.password);
      }
      onAuthSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fff9ed] flex flex-col items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', backgroundSize: '24px 24px' }}></div>

      <div className="w-full max-w-md bg-white border-4 border-black rounded-3xl shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] overflow-hidden relative z-10 animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="bg-[#FFDE00] border-b-4 border-black p-8 text-center relative">
           <div className="absolute top-4 left-4">
               <JugIcon className="w-8 h-8 text-black" fillLevel={0.6} />
           </div>
           <h1 className="text-3xl font-black italic tracking-tighter uppercase mb-1">Vault Access</h1>
           <p className="text-xs font-bold uppercase tracking-widest text-black/60">Identify Yourself</p>
        </div>

        {/* Content */}
        <div className="p-8">
            <div className="flex gap-4 mb-8">
                <button 
                    onClick={() => { setIsLogin(true); setError(''); }}
                    className={`flex-1 py-3 text-sm font-black uppercase tracking-wider border-2 border-black rounded-xl transition-all ${isLogin ? 'bg-black text-white shadow-[4px_4px_0px_0px_rgba(100,100,100,0.5)]' : 'bg-white text-gray-400 hover:text-black hover:bg-gray-50'}`}
                >
                    Login
                </button>
                <button 
                    onClick={() => { setIsLogin(false); setError(''); }}
                    className={`flex-1 py-3 text-sm font-black uppercase tracking-wider border-2 border-black rounded-xl transition-all ${!isLogin ? 'bg-black text-white shadow-[4px_4px_0px_0px_rgba(100,100,100,0.5)]' : 'bg-white text-gray-400 hover:text-black hover:bg-gray-50'}`}
                >
                    Register
                </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                    <div className="space-y-1">
                        <label className="text-xs font-black uppercase ml-1">Full Name</label>
                        <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input 
                                type="text"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                                className="w-full pl-10 pr-4 py-3 bg-gray-50 border-2 border-black rounded-xl font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_black] transition-all"
                                placeholder="Your Name"
                            />
                        </div>
                    </div>
                )}
                
                <div className="space-y-1">
                    <label className="text-xs font-black uppercase ml-1">Email Coordinates</label>
                    <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input 
                            type="email"
                            value={formData.email}
                            onChange={e => setFormData({...formData, email: e.target.value})}
                            className="w-full pl-10 pr-4 py-3 bg-gray-50 border-2 border-black rounded-xl font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_black] transition-all"
                            placeholder="name@company.com"
                        />
                    </div>
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-black uppercase ml-1">Passcode</label>
                    <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input 
                            type="password"
                            value={formData.password}
                            onChange={e => setFormData({...formData, password: e.target.value})}
                            className="w-full pl-10 pr-4 py-3 bg-gray-50 border-2 border-black rounded-xl font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_black] transition-all"
                            placeholder="••••••••"
                        />
                    </div>
                </div>

                {error && (
                    <div className="p-3 bg-red-100 border-2 border-red-500 rounded-xl text-red-600 text-xs font-bold flex items-center gap-2">
                        <ShieldCheck size={16} />
                        {error}
                    </div>
                )}

                <button 
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-[#2563EB] text-white border-2 border-black rounded-xl py-4 mt-4 font-black text-lg uppercase tracking-widest shadow-[4px_4px_0px_0px_black] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_black] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {isLoading ? <Loader2 className="animate-spin" /> : (
                        <>
                            {isLogin ? 'Unlock Vault' : 'Create Identity'}
                            <ArrowRight strokeWidth={3} />
                        </>
                    )}
                </button>
            </form>

            {/* Guest Mode Divider */}
            <div className="mt-8 relative flex items-center justify-center">
                 <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t-2 border-dashed border-gray-300"></div>
                 </div>
                 <span className="relative z-10 bg-white px-2 text-xs font-bold text-gray-400 uppercase tracking-widest">OR</span>
            </div>

            {/* Guest Button */}
            <button 
                onClick={onGuestAccess}
                className="w-full mt-6 bg-white text-gray-700 border-2 border-gray-300 hover:border-black hover:text-black rounded-xl py-3 font-bold text-sm uppercase tracking-wide transition-all flex items-center justify-center gap-2 group"
            >
                <Ghost size={16} className="group-hover:animate-bounce" />
                Just Browsing? Continue as Guest
            </button>
            <div className="mt-2 flex items-center justify-center gap-1.5 text-[10px] text-orange-600 font-bold bg-orange-50 py-1 px-2 rounded-md border border-orange-200">
                <AlertTriangle size={12} />
                Artifacts will disappear upon refresh
            </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 p-4 border-t-4 border-black text-center">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                Secure Career Architecture Protocol v1.0
            </p>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
