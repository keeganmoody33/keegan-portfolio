
export enum ArtifactType {
  STATS = 'STATS',
  PROJECT = 'PROJECT',
  DESIGN = 'DESIGN'
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface ChartDataPoint {
  label: string;
  value: number;
}

export interface ChartConfig {
  type: 'bar' | 'line' | 'pie' | 'area';
  color?: string;
  hideLabel?: boolean;
}

export interface GroundingSource {
  title?: string;
  uri?: string;
}

export interface RedactionZone {
  original: string;
  replacement: string;
  type: 'COMPANY' | 'PERSON' | 'FINANCIAL' | 'OTHER';
}

export interface ValidationBadge {
  verifier: string;
  date: string;
  type: 'PEER' | 'MANAGER' | 'SYSTEM';
  comment?: string;
}

export interface Artifact {
  id: string;
  title: string;
  type: ArtifactType;
  dateCreated: string;
  description: string; // The "Narrative"
  tags: string[];
  
  // Spec v1.0: Core Metrics
  impactScore?: number; // 0-100 calculated score
  fileHash?: string;    // SHA-256 for deduplication
  
  // "Intangible & Tangible" Fields
  inspiration?: string; // What sparked this?
  impact?: string; // Qualitative or Quantitative impact statement
  revenue?: string; // E.g., "$220,000"
  timeframe?: string; // E.g., "Q4 2024", "90 days"

  // Specific to Stats
  chartData?: ChartDataPoint[];
  chartConfig?: ChartConfig;
  metricUnit?: string;

  // Specific to Project/Design
  imageUrl?: string;
  videoUrl?: string;
  techStack?: string[];
  snippet?: string;
  
  // External Proof
  githubUrl?: string;
  linkUrl?: string;
  linkType?: 'GITHUB' | 'FIGMA' | 'LIVE' | 'OTHER';
  
  // Search Grounding
  groundingSources?: GroundingSource[];

  // Spec v1.0: Privacy & Trust
  redaction?: {
    isRedacted: boolean;
    zones: RedactionZone[];
  };

  validation?: {
    isVerified: boolean;
    badges: ValidationBadge[];
  };

  source?: string;
}

export interface UserProfile {
  name: string;
  role: string;
  joinDate: string;
}
