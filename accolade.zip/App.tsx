
import React, { useState, useEffect, useMemo } from 'react';
import { Artifact, ArtifactType, User } from './types';
import ArtifactCard from './components/ArtifactCard';
import CreateModal from './components/CreateModal';
import SummaryModal from './components/SummaryModal';
import PreviewModal from './components/PreviewModal';
import ChatWidget from './components/ChatWidget';
import AuthScreen from './components/AuthScreen';
import { JugIcon } from './components/Icons';
import { Plus, Search, Grid, List, Download, Wand2, Filter, FileText, Menu, X, FlaskConical, LogOut, User as UserIcon, Code2, Check, AlertTriangle, Ghost } from 'lucide-react';
import { isFeatureEnabled, toggleFeature, FEATURES } from './services/featureFlags';
import { authService } from './services/authService';

const JuiceLoader = () => {
  const [fill, setFill] = useState(0);

  useEffect(() => {
    // Animate the fill level of the jug
    const interval = setInterval(() => {
      setFill(prev => (prev >= 1 ? 0 : prev + 0.02));
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full pb-20 animate-in fade-in zoom-in duration-300">
      <div className="relative">
        <JugIcon 
            className="w-32 h-32 text-black drop-shadow-[8px_8px_0px_rgba(0,0,0,1)] transition-all duration-75" 
            fillLevel={fill} 
        />
        {/* Stirring Stick / Magic Wand Animation */}
        <div className="absolute -top-6 -right-6 animate-[spin_3s_linear_infinite]"> 
           <div className="bg-yellow-300 border-4 border-black p-3 rounded-full shadow-[4px_4px_0px_0px_black]">
               <Wand2 size={32} className="text-black" />
           </div>
        </div>
      </div>
      
      <div className="mt-12 text-center space-y-3">
         <h2 className="text-4xl font-black italic uppercase tracking-tighter">Mixing Elixirs...</h2>
         <p className="text-sm font-bold text-gray-500 tracking-widest uppercase">Decanting your wins</p>
         <div className="flex items-center justify-center gap-2 pt-2">
            <div className="w-3 h-3 bg-black rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-3 h-3 bg-black rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-3 h-3 bg-black rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
         </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTechFilters, setSelectedTechFilters] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthChecking, setIsAuthChecking] = useState(true);

  // Check Auth on Mount
  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
    setIsAuthChecking(false);
  }, []);

  // Load User Artifacts
  useEffect(() => {
    if (user) {
        if (user.id === 'guest') {
            // Guest mode: start empty, do not load from local storage
            setArtifacts([]);
            setIsLoading(false);
        } else {
            setIsLoading(true);
            // Simulate network fetch from "backend" (localStorage)
            setTimeout(() => {
                const savedData = localStorage.getItem(`accolade_artifacts_${user.id}`);
                if (savedData) {
                    setArtifacts(JSON.parse(savedData));
                } else {
                    setArtifacts([]); // Start empty for new users
                }
                setIsLoading(false);
            }, 1000);
        }
    }
  }, [user]);

  // Save Artifacts on Change
  useEffect(() => {
    // CRITICAL: Do NOT save if guest
    if (user && user.id !== 'guest' && !isLoading) {
        localStorage.setItem(`accolade_artifacts_${user.id}`, JSON.stringify(artifacts));
    }
  }, [artifacts, user, isLoading]);

  const handleSaveArtifact = (newArtifact: Artifact) => {
    setArtifacts(prev => [newArtifact, ...prev]);
  };

  const handleDeleteArtifact = (id: string) => {
    setArtifacts(prev => prev.filter(a => a.id !== id));
    setSelectedArtifact(null);
  };

  const handleGuestAccess = () => {
      setUser({
          id: 'guest',
          name: 'Guest Architect',
          email: ''
      });
  };

  const handleDownloadMarkdown = () => {
    if (artifacts.length === 0) return;

    const dateStr = new Date().toISOString().split('T')[0];
    const header = `# Accolade Vault Export
**User:** ${user?.name}
**Date:** ${dateStr}
**Total Artifacts:** ${artifacts.length}

---

`;

    const content = artifacts.map(a => {
        const visualNote = a.imageUrl || a.videoUrl 
            ? `\n> **Visual Attachment:** ${a.linkUrl ? `[View External Source](${a.linkUrl})` : 'Contains embedded media (see app)'}` 
            : '';

        return `## ${a.title}
**Type:** ${a.type} | **Timeframe:** ${a.timeframe || 'N/A'} | **Impact Score:** ${a.impactScore || 'N/A'}/100
**Tags:** ${a.tags.map(t => `#${t}`).join(' ')}

> ${a.description}
${visualNote}

**Impact:** ${a.impact || 'N/A'}
${a.revenue ? `**Revenue/Metric:** ${a.revenue}` : ''}
${a.inspiration ? `**Inspiration:** ${a.inspiration}` : ''}
${a.techStack?.length ? `**Tech Stack:** ${a.techStack.join(', ')}` : ''}
${a.githubUrl ? `[GitHub Repository](${a.githubUrl})` : ''}
${a.linkUrl ? `[External Link](${a.linkUrl})` : ''}

---
`;
    }).join('\n');

    const fullContent = header + content;
    const blob = new Blob([fullContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `accolade_vault_${dateStr}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Extract unique tech stacks from all artifacts
  const allTechStacks = useMemo(() => {
    return Array.from(new Set(artifacts.flatMap(a => a.techStack || []))).sort();
  }, [artifacts]);

  const toggleTechFilter = (tech: string) => {
    setSelectedTechFilters(prev => 
        prev.includes(tech) ? prev.filter(t => t !== tech) : [...prev, tech]
    );
  };

  const filteredArtifacts = artifacts.filter(a => {
    const matchesSearch = (a.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (a.tags || []).some(t => (t || '').toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesTech = selectedTechFilters.length === 0 || 
        (a.techStack || []).some(t => selectedTechFilters.includes(t));

    return matchesSearch && matchesTech;
  });

  // Calculate "Juice" Level (Cap at 10 artifacts for 100% full visual)
  const juiceLevel = Math.min(artifacts.length / 10, 1);

  // Collect all unique tags for auto-complete
  const uniqueTags = Array.from(new Set(artifacts.flatMap(a => a.tags || []).filter(t => t)));

  const isAdvancedEnabled = isFeatureEnabled(FEATURES.ADVANCED_VISUALIZATIONS);

  if (isAuthChecking) {
      return (
          <div className="h-screen w-full flex items-center justify-center bg-[#fff9ed]">
              <JuiceLoader />
          </div>
      );
  }

  if (!user) {
      return <AuthScreen onAuthSuccess={setUser} onGuestAccess={handleGuestAccess} />;
  }

  const isGuest = user.id === 'guest';

  return (
    <div className="h-screen w-full flex overflow-hidden bg-[#fff9ed] font-sans">
      
      {/* Mobile Top Header (Visible only on small screens) */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 h-16 bg-[#FFDE00] border-b-4 border-black flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
            <div className="bg-white border-2 border-black rounded-full p-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
               <JugIcon className="w-6 h-6 text-black" fillLevel={juiceLevel} />
            </div>
            <h1 className="text-xl font-black italic tracking-tight text-black">Accolade</h1>
        </div>
        <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 bg-white border-2 border-black rounded-lg shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all"
        >
            <Menu size={20} />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm animate-in fade-in duration-200"
            onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-white border-r-4 border-black flex flex-col h-full
        transform transition-transform duration-300 ease-in-out
        md:relative md:translate-x-0
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 flex items-center justify-between border-b-4 border-black bg-[#FFDE00]">
            <div className="flex items-center gap-4">
                {/* Dynamic Jug Icon */}
                <div className="bg-white border-2 border-black rounded-full p-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <JugIcon className="w-10 h-10 text-black transition-all duration-1000" fillLevel={juiceLevel} />
                </div>
                <div>
                    <h1 className="text-4xl font-black tracking-tight text-black italic leading-none">Accolade</h1>
                    <p className="text-[10px] uppercase font-bold text-black tracking-widest bg-white inline-block px-1 border border-black mt-1">Vault v1.0</p>
                </div>
            </div>
            {/* Close Button (Mobile Only) */}
            <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="md:hidden p-1 bg-white border-2 border-black rounded-full hover:bg-red-500 hover:text-white transition-colors"
            >
                <X size={20} />
            </button>
        </div>

        {/* User Profile Snippet */}
        <div className="px-6 pt-6 pb-2">
            {isGuest ? (
                <div className="flex flex-col gap-2 p-3 bg-orange-50 border-2 border-orange-200 rounded-xl relative overflow-hidden">
                    <div className="absolute -right-2 -top-2 text-orange-200">
                        <AlertTriangle size={48} />
                    </div>
                    <div className="flex items-center gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-black border border-black">
                            <Ghost size={16} />
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-black truncate text-orange-900">Guest Mode</p>
                            <p className="text-[10px] text-orange-700 font-bold truncate">Data Unsaved</p>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="flex items-center gap-3 p-3 bg-gray-50 border-2 border-black rounded-xl">
                    <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center font-black border border-black">
                        {user.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                        <p className="text-sm font-black truncate">{user.name}</p>
                        <p className="text-[10px] text-gray-500 font-bold truncate">Architect</p>
                    </div>
                </div>
            )}
        </div>

        <nav className="flex-1 p-6 space-y-6 overflow-y-auto">
            
            <div className="space-y-2">
                <button className="w-full flex items-center gap-3 px-4 py-3 bg-white text-black rounded-xl font-bold border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all">
                    <Grid size={20} />
                    <span className="text-lg">My Vault</span>
                </button>
            </div>

            <div className="space-y-3">
                 <div className="flex items-center gap-2 text-black/50">
                    <Filter size={14} />
                    <p className="text-xs font-black uppercase tracking-widest">Filter Flavors</p>
                 </div>
                 
                 <button className="w-full flex items-center justify-between px-4 py-2 bg-[#EFF6FF] text-black border-2 border-transparent hover:border-black hover:shadow-[2px_2px_0px_0px_#2563EB] rounded-lg text-sm font-bold transition-all group">
                    <span>Statistics</span>
                    <div className="w-3 h-3 rounded-full bg-[#2563EB] border border-black"></div>
                 </button>
                 <button className="w-full flex items-center justify-between px-4 py-2 bg-[#FEF2F2] text-black border-2 border-transparent hover:border-black hover:shadow-[2px_2px_0px_0px_#DC2626] rounded-lg text-sm font-bold transition-all group">
                    <span>Projects</span>
                    <div className="w-3 h-3 rounded-full bg-[#DC2626] border border-black"></div>
                 </button>
                 <button className="w-full flex items-center justify-between px-4 py-2 bg-[#FEFCE8] text-black border-2 border-transparent hover:border-black hover:shadow-[2px_2px_0px_0px_#FACC15] rounded-lg text-sm font-bold transition-all group">
                    <span>Designs</span>
                    <div className="w-3 h-3 rounded-full bg-[#FACC15] border border-black"></div>
                 </button>
            </div>

            {/* Tech Stack Filter */}
            {allTechStacks.length > 0 && (
                <div className="space-y-3 pt-6 border-t-2 border-gray-100">
                    <div className="flex items-center justify-between text-black/50">
                        <div className="flex items-center gap-2">
                            <Code2 size={14} />
                            <p className="text-xs font-black uppercase tracking-widest">Tech Stack</p>
                        </div>
                        {selectedTechFilters.length > 0 && (
                            <button 
                                onClick={() => setSelectedTechFilters([])}
                                className="text-[10px] font-bold text-red-500 hover:text-red-700 uppercase"
                            >
                                Clear
                            </button>
                        )}
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                        {allTechStacks.map(tech => {
                            const isSelected = selectedTechFilters.includes(tech);
                            return (
                                <button
                                    key={tech}
                                    onClick={() => toggleTechFilter(tech)}
                                    className={`px-2 py-1 text-[10px] font-bold uppercase border rounded transition-all flex items-center gap-1 ${
                                        isSelected
                                        ? 'bg-black text-white border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.5)]'
                                        : 'bg-white text-gray-600 border-gray-300 hover:border-black hover:text-black'
                                    }`}
                                >
                                    {tech}
                                    {isSelected && <Check size={10} />}
                                </button>
                            )
                        })}
                    </div>
                </div>
            )}
        </nav>

        <div className="p-6 border-t-4 border-black space-y-4 bg-gray-50">
            <div className="bg-white border-2 border-black rounded-xl p-4 shadow-[4px_4px_0px_0px_#9333EA]">
                 <div className="flex items-center gap-2 mb-2">
                    <Wand2 size={16} className="text-[#9333EA]" />
                    <p className="font-black text-sm text-black">Career Compilation</p>
                 </div>
                 <p className="text-xs text-gray-600 font-medium mb-3 leading-tight">Mash artifacts into a narrative.</p>
                 <button 
                    onClick={() => {
                        setIsMobileMenuOpen(false);
                        setIsSummaryModalOpen(true);
                    }}
                    className="w-full text-xs font-black bg-[#9333EA] text-white border-2 border-black px-3 py-2 rounded shadow-[2px_2px_0px_0px_black] hover:translate-y-px hover:shadow-[1px_1px_0px_0px_black] transition-all"
                 >
                    COMPILE BRIEF
                </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
                <button 
                    onClick={() => {}} 
                    className="border-2 border-black border-dashed rounded-xl p-3 flex flex-col items-center justify-center gap-2 hover:bg-white hover:border-solid transition-all text-gray-500 hover:text-black"
                >
                    <Download size={16} />
                    <span className="text-[10px] font-bold uppercase">PDF</span>
                </button>
                <button 
                    onClick={handleDownloadMarkdown}
                    className="bg-black text-white rounded-xl p-3 flex flex-col items-center justify-center gap-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,0.5)] hover:bg-gray-800 transition-all"
                >
                    <FileText size={16} />
                    <span className="text-[10px] font-bold uppercase">Markdown</span>
                </button>
            </div>
            
            {/* Logout & Feature Flags */}
            <div className="flex items-center justify-between pt-2 border-t-2 border-gray-200">
                <button 
                    onClick={() => {
                        if (isGuest) {
                            setUser(null); // Just clear state for guest
                        } else {
                            authService.logout();
                        }
                    }}
                    className="flex items-center gap-2 text-xs font-bold text-red-500 hover:text-red-700 transition-colors"
                >
                    <LogOut size={14} />
                    <span>{isGuest ? 'EXIT GUEST MODE' : 'SIGN OUT'}</span>
                </button>

                <div 
                    className="flex items-center gap-2 cursor-pointer opacity-50 hover:opacity-100 transition-opacity"
                    onClick={() => toggleFeature(FEATURES.ADVANCED_VISUALIZATIONS)}
                >
                   <div className={`w-2 h-2 rounded-full ${isAdvancedEnabled ? 'bg-green-500' : 'bg-gray-300'}`} />
                   <FlaskConical size={12} className="text-gray-400" />
                </div>
            </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full relative pt-16 md:pt-0">
        
        {/* Top Header */}
        <header className="h-20 md:h-24 bg-white border-b-4 border-black px-4 md:px-8 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-4 flex-1 max-w-xl">
                <div className="relative w-full group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-black w-5 h-5" />
                    <input 
                        type="text" 
                        placeholder="Search artifacts..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-12 pr-4 py-2.5 md:py-3 bg-white border-2 border-black rounded-full text-sm font-bold outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all placeholder-gray-400 text-black"
                    />
                </div>
            </div>

            <div className="flex items-center gap-2 md:gap-4 ml-3">
                 <button 
                    onClick={() => setIsModalOpen(true)}
                    className="bg-[#FF4D4D] text-white border-2 border-black px-3 md:px-6 py-2.5 md:py-3 rounded-xl text-sm font-black flex items-center gap-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] transition-all uppercase"
                 >
                    <Plus size={20} strokeWidth={3} />
                    <span className="hidden sm:inline">New Artifact</span>
                 </button>
            </div>
        </header>

        {/* Scrollable Vault Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 relative">
            
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', backgroundSize: '24px 24px' }}></div>

            <div className="max-w-7xl mx-auto relative z-10 h-full">
                {isLoading ? (
                    <JuiceLoader />
                ) : (
                    <>
                        {/* Hero / Empty State */}
                        {artifacts.length === 0 && (
                            <div className="text-center py-12 md:py-20 bg-white border-4 border-black rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 md:p-12 max-w-2xl mx-auto mt-4 md:mt-0 animate-in fade-in zoom-in duration-300">
                                <div className="w-20 h-20 md:w-24 md:h-24 bg-yellow-300 rounded-full border-4 border-black flex items-center justify-center mx-auto mb-6 shadow-[4px_4px_0px_0px_black]">
                                    <JugIcon className="w-10 h-10 md:w-12 md:h-12 text-black" />
                                </div>
                                <h2 className="text-2xl md:text-4xl font-black text-black mb-4 uppercase italic">Vault Empty!</h2>
                                <p className="text-base md:text-lg text-gray-600 font-medium mb-8">
                                    Start collecting your wins. Add statistics, code, or designs to fill the jug.
                                    {isGuest && <span className="block mt-2 text-red-500 font-bold text-sm bg-red-50 border border-red-200 rounded-lg p-2 max-w-sm mx-auto">⚠ Guest Mode: Artifacts are not saved.</span>}
                                </p>
                                <button onClick={() => setIsModalOpen(true)} className="text-white bg-black px-6 md:px-8 py-3 md:py-4 rounded-xl font-black text-lg md:text-xl hover:bg-gray-800 border-2 border-transparent hover:border-black transition-all shadow-[4px_4px_0px_0px_rgba(0,0,0,0.3)]">
                                    CREATE ARTIFACT #1
                                </button>
                            </div>
                        )}

                        {/* Grid */}
                        {artifacts.length > 0 && (
                             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8 pb-20">
                                {filteredArtifacts.map((artifact) => (
                                    <div key={artifact.id} className="h-[420px]">
                                        <ArtifactCard 
                                            artifact={artifact} 
                                            onPreview={setSelectedArtifact} 
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
      </main>

      <ChatWidget />

      <CreateModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSave={handleSaveArtifact} 
        existingTags={uniqueTags}
      />

      <SummaryModal
        isOpen={isSummaryModalOpen}
        onClose={() => setIsSummaryModalOpen(false)}
        artifacts={artifacts}
      />

      <PreviewModal 
        artifact={selectedArtifact}
        onClose={() => setSelectedArtifact(null)}
        onDelete={handleDeleteArtifact}
      />
    </div>
  );
};

export default App;
