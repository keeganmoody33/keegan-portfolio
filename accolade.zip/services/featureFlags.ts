
export const FEATURES = {
  ADVANCED_VISUALIZATIONS: 'advanced_visualizations',
};

// Check if a feature is enabled
export const isFeatureEnabled = (feature: string): boolean => {
  if (typeof window === 'undefined') return false;
  // Default to false unless explicitly enabled in localStorage
  return localStorage.getItem(`feature_${feature}`) === 'true';
};

// Toggle a feature
export const toggleFeature = (feature: string) => {
  const current = isFeatureEnabled(feature);
  localStorage.setItem(`feature_${feature}`, (!current).toString());
  // Reload to apply changes cleanly across the app
  window.location.reload();
};
