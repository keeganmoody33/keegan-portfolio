
import { GoogleGenAI, Modality } from "@google/genai";
import { Artifact, ArtifactType, GroundingSource, RedactionZone, ChartConfig } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface NarrativeResponse {
  title: string;
  description: string;
  tags: string[];
  inspiration?: string;
  impact?: string;
  impactScore: number; // 0-100
  revenue?: string;
  timeframe?: string;
  techStack?: string[];
  snippet?: string;
  redactionSuggestions?: RedactionZone[];
}

interface NarrativeResult {
  narrative: NarrativeResponse;
  sources: GroundingSource[];
}

export const generateArtifactNarrative = async (
  rawText: string,
  type: ArtifactType,
  media: { data: string, mimeType: string } | null = null,
  anonymize: boolean = false,
  externalLink?: string
): Promise<NarrativeResult> => {
  
  // Determine Model and Config based on feature requirements
  let modelId = 'gemini-3-flash-preview';
  let config: any = { responseMimeType: "application/json" };
  const parts: any[] = [];

  // Feature: Video & Image Understanding
  // Requirement: Use gemini-3-pro-preview for analysis
  if (media) {
    modelId = 'gemini-3-pro-preview';
    parts.push({ inlineData: { mimeType: media.mimeType, data: media.data } });
  } 
  // Feature: Search Grounding
  // Requirement: Use gemini-3-flash-preview with googleSearch if link is present
  else if (externalLink) {
    modelId = 'gemini-3-flash-preview';
    config.tools = [{ googleSearch: {} }];
  }

  const prompt = `
    Analyze the following input and generate a JSON object for a professional portfolio artifact.
    
    Input Type: ${type}
    ${externalLink ? `Context URL: ${externalLink} (Use Google Search to verify or enrich details)` : ''}
    Raw Input: "${rawText}"
    
    ${anonymize ? `
    *** PRIVACY SHIELD ACTIVATED ***
    The user wants to anonymize this artifact. 
    1. Replace specific employer/company names with aliases (e.g. "Client A").
    2. Redact sensitive names.
    ` : ''}

    Requirements:
    1. "title": A professional, punchy title.
    2. "description": A concise professional summary (STAR method).
    3. "tags": 3-4 relevant tags.
    4. "inspiration": Infer the motivation/problem.
    5. "impact": A specific statement about the outcome.
    6. "impactScore": Evaluate the professional significance on a scale of 0-100 based on metrics, complexity, and scale.
    7. "revenue": Extracted financial value (formatted).
    8. "timeframe": Extracted time period.
    9. "techStack": Extracted technologies.
    10. "snippet": For PROJECT, a code snippet (raw text).
    11. "redactionSuggestions": If anonymize is TRUE, list the zones that were/should be redacted.

    Output JSON Format:
    {
      "title": "string",
      "description": "string",
      "tags": ["string"],
      "inspiration": "string",
      "impact": "string",
      "impactScore": number,
      "revenue": "string | null",
      "timeframe": "string | null",
      "techStack": ["string"],
      "snippet": "string | null",
      "redactionSuggestions": [
        { "original": "string", "replacement": "string", "type": "COMPANY" | "PERSON" | "FINANCIAL" }
      ]
    }
  `;
  
  parts.push({ text: prompt });

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: { parts },
      config: config
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    // Extract Grounding Sources if Search was used
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources: GroundingSource[] = groundingChunks
      ?.map(c => c.web)
      .filter((w): w is GroundingSource => !!w) || [];
    
    // Defensive Parsing to ensure required fields exist
    const parsed = JSON.parse(text);
    const safeNarrative: NarrativeResponse = {
        ...parsed,
        title: parsed.title || "Untitled Artifact",
        description: parsed.description || "No description available.",
        tags: Array.isArray(parsed.tags) ? parsed.tags.filter((t: any) => typeof t === 'string') : [],
        impactScore: typeof parsed.impactScore === 'number' ? parsed.impactScore : 50
    };

    return {
      narrative: safeNarrative,
      sources
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      narrative: {
        title: "New Artifact",
        description: rawText || "Media Artifact",
        tags: ["Draft"],
        impact: "Pending analysis",
        impactScore: 50
      },
      sources: []
    };
  }
};

export const parseStatsData = async (rawText: string): Promise<{ data: { label: string, value: number }[], unit: string, chartConfig?: ChartConfig }> => {
    // Use Flash for speed
    const modelId = 'gemini-3-flash-preview';
    const prompt = `
      Extract statistical data from the following text for visualization.
      
      Tasks:
      1. Extract data points (label/value).
      2. Identify the unit (e.g., $, %, count).
      3. Recommend the BEST visualization type based on the data:
         - 'line': For continuous trends or time-series data.
         - 'bar': For comparing categories or discrete time periods.
         - 'pie': For parts of a whole (percentages totaling 100%).
         - 'area': For volume/growth trends over time.
      
      Text: "${rawText}"
      
      Output JSON:
      {
        "data": [ {"label": "Jan", "value": 100}, ... ],
        "unit": "$",
        "chartConfig": {
            "type": "bar" | "line" | "pie" | "area"
        }
      }
    `;

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: prompt,
            config: {
                responseMimeType: "application/json"
            }
        });
        
        const text = response.text;
        if (!text) return { data: [], unit: "" };
        const result = JSON.parse(text);
        
        // Ensure defaults
        if (!result.chartConfig) result.chartConfig = { type: 'bar' };
        
        return result;
    } catch (e) {
        console.error("Failed to parse stats", e);
        return { data: [], unit: "" };
    }
}

export const generateVaultSummary = async (artifacts: Artifact[]): Promise<string> => {
    if (artifacts.length === 0) return "No artifacts to compile.";

    const context = artifacts.map(a => `
      - Title: ${a.title}
      - Type: ${a.type}
      - Impact: ${a.impact || 'N/A'} (Score: ${a.impactScore || 'N/A'})
      - Revenue: ${a.revenue || 'N/A'}
      - Timeframe: ${a.timeframe || 'N/A'}
      - Tech Stack: ${a.techStack?.join(', ') || 'N/A'}
      - Description: ${a.description}
    `).join('\n');

    const prompt = `
      You are an expert Career Architect.
      
      Task: Compile these disparate artifacts into one cohesive "Executive Bio" or "Career Narrative".
      
      Artifacts:
      ${context}
      
      Instructions:
      1. Write a 2-paragraph professional biography weaving these wins together.
      2. If revenue figures exist, calculate a "Total Value Created" estimate and mention it.
      3. Identify a "Career Archetype" for this person (e.g., "The Revenue Engine", "The Product Visionary").
      4. List 3 "Superpowers" derived from the combination of these artifacts.
      5. Output in clean Markdown format. Use ## for headers.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 32768 }
            }
        });
        return response.text || "Could not generate summary.";
    } catch (e) {
        console.error("Failed to generate summary", e);
        return "Error generating summary.";
    }
}

export const transcribeAudio = async (audioBase64: string, mimeType: string): Promise<string> => {
    const prompt = "Transcribe the following audio exactly as spoken. Do not add any commentary.";
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType, data: audioBase64 } },
                    { text: prompt }
                ]
            }
        });
        return response.text || "";
    } catch (e) {
        console.error("Transcription failed", e);
        return "";
    }
};

// FEATURE: Generate Speech (TTS)
export const generateArtifactSpeech = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-tts',
            contents: { parts: [{ text }] },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return audioData || "";
    } catch (error) {
        console.error("TTS Error:", error);
        return "";
    }
};

// FEATURE: Nano Banana Image Editing
export const editArtifactImage = async (imageBase64: string, prompt: string): Promise<string> => {
     // Strip header if present for clean base64
     const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");
     
     try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: cleanBase64 } },
                    { text: prompt }
                ]
            }
        });
        
        // Iterate parts to find inlineData
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData && part.inlineData.data) {
                return part.inlineData.data;
            }
        }
        return "";
     } catch (error) {
         console.error("Image Edit Error:", error);
         return "";
     }
}

// FEATURE: AI Chatbot
export const chatWithGemini = async (history: {role: string, parts: {text: string}[]}[], message: string): Promise<string> => {
    try {
        const chat = ai.chats.create({
            model: 'gemini-3-pro-preview',
            history: history
        });
        const result = await chat.sendMessage({ message });
        return result.text || "I didn't catch that.";
    } catch (e) {
        console.error("Chat Error", e);
        return "I am currently unavailable.";
    }
}
