lecturesfrom brand kit · v0 · 2026-10-14

logo/       the mark (logo A, geometric). svg for screens, png when svg is refused,
            print/ eps + pdf for printers and plants (strokes, not outlined yet).
lockups/    the mark plus the name in Chakra Petch 600. horizontal and vertical,
            ink and white, with or without a ground. svg text is outlined.
favicon/    favicon with a white plate inside the circle, so it reads on dark tabs.
avatars/    400 and 1024, light and dark, safe inside a circle crop.
app-icons/  1024 full bleed and 512 maskable, light and dark.
slack/      128 emoji with white plate, plus lf-spin.gif (the orbit turning once).
tokens/     house.css, the canonical color + type tokens.
manifest.json  every site file with size, sha256, and its frozen hashed URL.

type: Chakra Petch 600 for display, Roboto Mono for body. both on Google Fonts.
name: lecturesfrom. one word, always lowercase. "lecturesfrom LLC" only in legal lines.
rules: no rotating, recoloring, stretching, effects, or anything inside the circle.
full guide: lecturesfrom.com/brand
